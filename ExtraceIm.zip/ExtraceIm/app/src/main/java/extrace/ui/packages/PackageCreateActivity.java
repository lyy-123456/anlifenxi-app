package extrace.ui.packages;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import extrace.ui.main.R;


public class PackageCreateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_create);

    }
}
